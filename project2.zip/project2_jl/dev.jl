include("run.jl") 
dev_main("simple1", 1, optimize)